# Ollama App

## Linux

TODO

## MacOS

TODO

## Windows

If you want to build the installer, youll need to install
- https://jrsoftware.org/isinfo.php


In the top directory of this repo, run the following powershell script
to build the ollama CLI, ollama app, and ollama installer.

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\build_windows.ps1
```
