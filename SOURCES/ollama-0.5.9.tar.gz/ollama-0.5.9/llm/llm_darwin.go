package llm

import (
	"syscall"
)

var LlamaServerSysProcAttr = &syscall.SysProcAttr{}
